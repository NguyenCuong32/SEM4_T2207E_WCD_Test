package com.example.ExamTranThiMaiHien;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamTranThiMaiHienApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamTranThiMaiHienApplication.class, args);
	}

}
