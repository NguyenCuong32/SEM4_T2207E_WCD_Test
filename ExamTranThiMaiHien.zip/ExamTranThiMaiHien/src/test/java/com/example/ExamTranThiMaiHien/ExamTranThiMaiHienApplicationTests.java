package com.example.ExamTranThiMaiHien;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamTranThiMaiHienApplicationTests {

	@Test
	void contextLoads() {
	}

}
